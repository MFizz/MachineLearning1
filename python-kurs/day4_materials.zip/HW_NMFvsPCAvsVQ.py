'''Homework III - Task 1

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_NMFvsPCAvsVQ.py

1.  Start Ipython with pylab from the shell: type
    xxx$ ipython --pylab

2.  From Ipython, use 
    In [xxx]: import HW_NMFvsPCAvsVQ as NMFvs
    to make the functions available

3.  If you make changes, type 
    In [xxx]: NMFvs = reload(NMFvs)
    to makes the new versions available in Ipython

4. The file contains a function sandbox(). Type
    In [xxx]: NMFvs.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    
    
    Questions? Do not hesitate to ask!
'''
import numpy as np
import scipy.linalg as la
import scipy.io
import pylab as pl

import matplotlib.gridspec as gridspec

import nmf
import HW_nmf_utils as nmfu
import kmeans_utils as kmu
import bimp 
reload(nmf)
reload(nmfu)
reload(kmu)
reload(bimp)

# import HW_VQandKmeans as hw_vqkm
# reload(hw_vqkm)
# import HW_PCA as hw_pca
# reload(hw_pca)

def plot_col(mat, i=0):
    ''' your header here '''
    # your code here
    return

def write_op(op,fsize):
    ''' your header here '''
    # your code here
    return


def NMFvsPCAvsVQ(dataset, vgrid=(7,7), ind=0 ):
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
    '''
    # your code here


    pl.savefig(dataset+'.pdf')    
    return
    
def profile_project():
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
    '''
    print 'data set usps:'
    print 'how long does code execution take?'
    print '...'    
    print 'how many iterations does nmf need?'    
    print '...'    
    print 'how many iterations does kmeans need?'    
    print '...'    
    print 'which method is fastest? Is the difference large?'
    print '...'            
    print 'which method is slowest? Is the difference small?'
    print '...'    
    
    print 'data set swimmer:'
    print 'how long does code execution take?'
    print '...'    
    print 'how many iterations does nmf need?'    
    print '...'    
    print 'how many iterations does kmeans need?'    
    print '...'    
    print 'which method is fastest? Is the difference large?'
    print '...'            
    print 'which method is slowest? Is the difference small?'
    print '...'    

    print 'data set orl32:'
    print 'how long does code execution take?'
    print '...'    
    print 'how many iterations does nmf need?'    
    print '...'    
    print 'how many iterations does kmeans need?'    
    print '...'    
    print 'which method is fastest? Is the difference large?'
    print '...'            
    print 'which method is slowest? Is the difference small?'
    print '...'    

def pca(X, k):
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
    '''
    # your code here
    xy, n = X.shape
    # meanI =  X.mean(1, keepdims=True)
    meanI =  np.mean(X, 1)[:,np.newaxis]
    im_demeaned = X - meanI
    C_np = np.cov(im_demeaned)
    l2, v2 =  la.eigh( C_np )
    inds = np.argsort( l2 )
    v2 = v2[:, inds[::-1]]
    l2 = l2[inds[::-1]]
    
    W = v2[:,:k-1]
    H = np.dot( W.T, im_demeaned )
    norm = np.sqrt(np.sum(  meanI**2  ))
    W = np.append( meanI/norm, W, axis=1 )
    H = np.append( norm*np.ones( (1,n) ), H, axis=0 )
    return W, H

def kmeans(X, k):
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
        *
        Hint: use a while-loop and test for convergence
        Hint: use the functions from kmeans_util.py (already imported as kmu)
    '''
    # your code here
    M = X[:,:k]
    converged = False
    while not converged:
        D = kmu.distmat(M, X)
        A = kmu.closest(D)
        Mnew = kmu.newcenters(X, A)
        converged = np.all( Mnew == M )
        M = Mnew
    return M
    
def vq(X, k):
    ''' your Header here!
        
    Instructions:
        see exercise sheet!
        *
        Hint: call kmeans!
    '''
    # your code here
    W = kmeans(X, k)
    D = kmu.distmat(W, X)
    H = kmu.closest(D)
    return W, H
        
def sandbox():
    print 'put text into a figure'
    pl.figure()
    pl.subplot(2,1,1)
    pl.text(0.1,0.7,'some text',fontsize=24,ha='left',va='center')

    pl.subplot(2,1,2)
    pl.text(0.1,0.7,'some more text',fontsize=24,ha='left',va='center')
    pl.xticks([],[])
    pl.yticks([],[])
    pl.box('off')    
    
    print 'type "pl.text?" for more info!'
