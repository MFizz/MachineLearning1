'''Day 3 -- Exercises V
'''

import numpy as np

def seung_objective(V, W, H):
    ''' calculated the non-negative matrix factorization objective
        
    Usage:
        W, H = seung_update(V, W, H)
    Parameters:
        V: a (d x n)-array containing n observations in the columns
        W: (d x k)-array of non-negative basis images (components)
        H: (k x n)-array of weights, one column for each of the n observations
    Returns:
        F: a scalar objective
          
    Instructions:
        - see exercise sheet!
    '''
    # your code here
    return F
    
def seung_updateW(V, W, H):
    ''' performs the multiplicative non-negative matrix factorization updates for W
        
    Usage:
        W, H = seung_update(V, W, H)
    Parameters:
        V: a (d x n)-array containing n observations in the columns
        W: (d x k)-array of non-negative basis images (components)
        H: (k x n)-array of weights, one column for each of the n observations
    Returns:
        W: (d x k)-array of updated non-negative basis images (components)
          
    Instructions:
        - see exercise sheet!
    '''
    # your code here
    return W

def seung_updateH(V, W, H):
    ''' performs the multiplicative non-negative matrix factorization updates
        
    Usage:
        W, H = seung_update(V, W, H)
    Parameters:
        V: a (d x n)-array containing n observations in the columns
        W: (d x k)-array of non-negative basis images (components)
        H: (k x n)-array of weights, one column for each of the n observations
    Returns:
        H: (k x n)-array of updated weights, one column for each of the n observations
          
    Instructions:
        - see exercise sheet!
    '''
    # your code here
    return H


def seung_nmf(V, k, threshold=1e-6):
    ''' decomposes X into r components by non-negative matrix factorization
        
    Usage:
        W, H = seung_nmf(X, r)
    Parameters:
        V: a (d x n)-array containing n observations in the columns
        k: number of components to extract
        threshold: relative error threshold of the iteration
    Returns:
        W: (d x k)-array of non-negative basis images (components)
        H: (k x n)-array of weights, one column for each of the n observations
          
    Instructions:
        - see exercise sheet!
        *
    '''
    # your code here
    return W, H
    
def sandbox():
    print 'remember that you can:'    
    print '...multiply matrices elementwise:'    
    A = np.random.randn( 2, 3)
    B = np.random.randn( 2, 3)
    C = A * B
    print 'C = A * B = \n', C

    print '\n...use broadcasting:'
    C = A / np.sum(B,0)
    print 'C = A / np.sum(B,0) = \n', C
    C = A / np.sum(B,1)[:,np.newaxis]
    print 'C = A / np.sum(B,1)[:,np.newaxis] = \n', C
    
    print '\n...you can directly assign a truth value:'
    print "A = 'A'; B = 'B'; X = 'A'"
    A = 'A'; B = 'B'; X = 'A'
    AisB = A == B
    print 'AisB = ', AisB
    AisX = A == X
    print 'AisX = ', AisX
    

def test_mod():
    '''tests for seung_objective and seung_update'''
    W = np.arange(6); W = W.reshape(3,2).astype('float')
    H = np.arange(8); H = H.reshape(2,4).astype('float')
    V = np.arange(12); V = V.reshape(3,4).astype('float')

    print '\nTesting seung_objective....'
    F = seung_objective(V, W, H)
    assert( abs(-24.2475007259 - F) < 1e-8 ) 
    print 'seung_objective passed the test!'

    Wtest = [[ 0., 0.10598807], [ 0.34448888,  0.33148298], [ 0.65551112,  0.56252896]], 
    Htest = [[  0.,           2.56148015,   4.34133691,   5.82079282],
             [ 12.,          12.43851985,  13.65866309,  15.17920718]]
    print '\nTesting seung_updateW....'
    W = seung_updateW(V, W, H)
    assert( np.all( W - Wtest <= 1e-6) )
    print 'seung_updateW passed the  test!'
    
    print '\nTesting seung_updateH....'
    H = seung_updateH(V, W, H)
    assert( np.all( H - Htest <= 1e-8) )
    print 'seung_updateH passed the  test!'

    print '\nTesting seung_nmf....'
    W, H = seung_nmf(V,2)
    F = seung_objective(V, W, H) 
    assert( F > 50 )
    print 'seung_nmf passed the  test!'    
    print '\nTests passed!'