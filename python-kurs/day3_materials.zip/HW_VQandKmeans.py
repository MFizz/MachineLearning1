'''Homework II -- Task 3

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_VQandKmeans.py

1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab

2.  From Ipython, use 
    In [xxx]: import HW_VQandKmeans as vqkm
    to make the functions available

3.  If you make changes, type 
    In [xxx]: vqkm = reload(vqkm)
    to makes the new versions available in Ipython

4. The file contains a function sandbox(). Type
    In [xxx]: vqkm.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    

5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    In [xxx] vqkm.test_mod()
    
    Questions? Do not hesitate to ask!
'''
import numpy as np
import scipy.linalg as la
import pylab as pl
import kmeans_utils as kmu

def kmeans(X, k):
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
        *
        Hint: use a while-loop and test for convergence
        Hint: use the functions from kmeans_util.py (already imported as kmu)
    '''
    # your code here
    
def vq(X, k):
    ''' your Header here!
        
    Instructions:
        see exercise sheet!
        *
        Hint: call kmeans!
    '''
    # your code here
    return W, H

def usps_neighbours():
    ''' your Header here!
        
    Instructions:
        see exercise sheet!
        *
        Hint: check the sandbox for pie plots!
    '''
    # your code here

def usps_kmeans():
    ''' your Header here!
        
    Instructions:
        see exercise sheet!
        *
        Hint: check the sandbox for pie plots!
    '''
    # your code here

def sandbox():
    print 'An example for an iterative algorithm: '
    print "Heron's methon of calculating square roots"
    S = 2.
    x = S
    converged = False
    while not converged:
        xnew = 0.5*( x + S/x)
        converged =  abs(x-xnew) < 1e-10 
        x = xnew
    print 'the square root of ' + str(S) + ' is ' + str(x)
    print 'comparison: np.sqrt(S) = ', np.sqrt(S)
    
    print 'examples of pie plots:'

    print 'a very simple pie plot'
    pl.subplot(1,2,1)
    sizes = [10, 11, 12, 13, 14,15,16,17,18,19]    
    pl.pie(sizes)
    pl.axis('equal')

    print 'a more advanced pie plot'
    pl.subplot(1,2,2)
    # The slices will be ordered and plotted counter-clockwise.
    labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
    sizes = [1.5, 3.0, 4.5, 1.0, ]
    colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral']
    explode = (0, 0.1, 0, 0) # only "explode" the 2nd slice (i.e. 'Hogs')
    pl.pie(sizes, explode=explode, labels=labels, colors=colors,
           autopct='%1.1f%%', shadow=True)
    pl.axis('equal')
    pl.show()
        
def test_mod():
    '''test the functions'''
    X = np.array([  [ 0., 1., 2., 3., 10.], 
                    [ 0., 0., 0., 0., 0.], 
                    [ 0., 0., 0., 0., 0.],     ])
    M = kmeans(X,2)
    assert(     np.all( np.array([  [  1.5,  10. ],
                                    [  0.,    0. ],
                                    [  0. ,   0. ]] ) == M  )     )
    
    W, H = vq(X, 2)
    assert(     np.all( np.array([  [  1.5,  10. ],
                                    [  0.,    0. ],
                                    [  0. ,   0. ]] ) == W  )     )
    
    assert( np.all( np.array(   [[ True,  True,  True,  True, False],
                                [False, False, False, False,  True]] ) == H )    )
    print 'Tests passed!'