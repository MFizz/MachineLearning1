''' Day 2 -- Exercises 4
    
    
    General Instructions and Hints:
    0.  Open a shell and change to the directory where the course material lies:
        xxx$ cd YOUR_FOLDER
        xxx$ ls
        The ls command should show kmeans_util.py
    1.  Start Ipython with from the shell: type
        xxx$ ipython --pylab
    2.  From Ipython, use 
        In [xxx]: import kmeans_util as kmu
        to make the functions available
    3.  If you make changes, type 
        In [xxx]: kmu = reload(kmu)
        to makes the new versions available in Ipython
    4. The file contains a function sandbox(). Type
        In [xxx]: kmu.sandbox()
        to run some code snippets which might be useful for the exercises
        Feel free to play around with these snippets!
    5.  The file contains a module which does some tests! 
        When you have finished a function, type 
        In [xxx] kmu.test_mod()
    
    Questions? Do not hesitate to ask!
'''

import numpy as np
import scipy.linalg as la
import pylab as pl


def distmat(M, X):
    ''' calculates a distance matrix between M and X
        
    Usage:
        D = distmat( M, X )
    Parameters:
        M: (d x k) array of column vectors
        X: (d x n) array of column vectors
    Returns:
        D: (k x n) array of distances between the vectors in M and X
    
    Instructions:
        see exercise sheet!
        *
        Hint: use matrix multiplications (dot-product) to avoid for-loops!
        Hint: Though this can be done as a one-liner, maybe it helps to specify 
                M2, MX and X2 explicitly
        Hint: if you use sum(), consider the keepdims=True option
        Hint: think about the dimensions and use broadcasting!
    '''
    # your code here
    
def closest(D):
    ''' returns an index matrix of the minima in the columns
        
    Usage:
        A = closest( D )
    Parameters:
        D: (k x n) array of distances
    Returns:
        A: (k x n) array  with ones at the places of the column minimas
    
    Instructions:
        see exercise sheet!
        *
        Hint: use numpy.min
    '''
    # your code here
    
def newcenters(X, A):
    ''' returns matrix of new k-Mean centers
        
    Usage:
        M = newcenters(X, A)
    Parameters:
        A: (k x n) array  with ones at the places of the column minimas
        X: (d x n) array  with ones at the places of the column minimas
    Returns:
        M: (d x k) array of k new centers
    
    Instructions:
        see exercise sheet!
        *
        Hint: use numpy.min
    '''
    # your code here

def sandbox():
    print 'let us first generate a column vector:'
    a = np.arange(1,6)[:,np.newaxis]
    print 'a = '
    print a
    
    print '\ncalculate the norm of the vector:'
    norm_a = np.sum(a**2)
    print 'squared norm = ', norm_a
    
    print '\ncalculate the norm of columns of a matrix:'
    print '(and keep the shape):'
    A = np.random.rand(2,3)
    print 'A = ', A
    print 'shape of A = ', A.shape
    norm_A = np.sum(A**2,0)[np.newaxis,:]
    print 'squared norm = ', norm_A
    print 'shape of norm = ', norm_A.shape
    
    print '\nsquare root is available as a numpy function:'
    print 'norm = ', np.sqrt(norm_a)

    print '\nlogical indexing:'
    a = np.random.rand(5,6)
    print '\n find all entries in a smaller than 0.5'
    inds = a < 0.5
    print '\nset those entries to zero:'
    a[inds] = 0
    print a
    

    
def test_mod():
    '''test the three routines'''
    X = np.array([  [ 1., 1., 0., 0.], 
                    [ 0., 1., 0., 1.], 
                    [ 1., 0., 1., 0.],     ])
    M = X[:,:2]
    D = distmat(M,X)
    assert(     np.sum( np.array([[ 0.,  2.,  1.,  3.], [ 2.,  0.,  3.,  1.]] ) - D**2 ) <= 1e-8   )
    
    A = closest(D)
    assert(     np.all( np.array([[ True, False,  True, False],
                                 [False,      True, False,  True]] ) == A ))    
    
    Mnew = newcenters(X, A)
    assert(     np.sum( np.array([[ 0.5,  0.5],
                                 [ 0.,   1. ],
                                 [ 1.,   0. ]]     ) - Mnew ) <= 1e-8   )
    print 'Tests passed'