''' Day 1 -- Exercises 1 -- Task 3
    and
    Day 1 -- Exercises 2 -- Task 4


General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show limaalg.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import limaalg as lima"
    to make the functions available
3.  If you make changes, type 
    In [xxx]: lima = reload(lima)
    to makes the new versions available in Ipython
4. The file contains two sandbox-function. Type
    In [xxx]: lima.sandbox_lima()       # for Exercises 1 Task 3
    In [xxx]: lima.sandbox_numpy()      # for Exercises 2 Task 4
    to run some code snippets which might be useful for the exercises.
    Feel free to play around with these snippets!
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    >>> lima.test_mod_lima()            # for Exercises 1 Task 3
    >>> lima.test_mod_numpy()           # for Exercises 2 Task 4
    
    Questions? Do not hesitate to ask!
'''

import math
import random

def zeros_lima(dims):
    ''' generate a list matrix of zeros 
        
    Usage:
        A = zeros_lima( (r,c) )
    Parameters:
        dims: a tuple (r,c) containing numbers r and c of rows and columns (int, int)
    Returns:
        A: a list matrix (r x c) with 0. in every entry
    
    Instructions:
        see exercise sheet!
        *
        Hint: with list comprehensions, this is easier than with for-loops!
    '''
    r, c = dims
    # your code here!
    
def rand_lima(dims):
    ''' generate a list matrix of random entries
        
    Usage:
        A = rand_lima( (r,c) )
    Parameters:
        dims: a tuple (r,c) containing numbers r and c of rows and columns (int, int)
    Returns:
        A: a list matrix (r x c) with random entries
    
    Instructions:
        see exercise sheet!
        *
        Hint: use random.random() for random number generation
        Hint: with list comprehensions, this is easier than with for-loops!
    '''
    # your code here!
    
def emul_lima(A, B):
    ''' elementwise product of list matrices A and B
        
    Usage:
        C = emul_lima( A, B )
    Parameters:
        A, B: list matrices of identical dimensions
    Returns:
        C: a list matrix with the elementwise product
    
    Instructions:
        see exercise sheet!
        *
        Hint: try len(A) and len(A[0]) on list matrices
        Hint: with list comprehensions, this is easier than with for-loops!
    '''
    # your code here!
    
def matmul_lima(A, B):
    ''' dot product of list matrices A and B
        
    Usage:
        C = matmul_lima( A, B )
    Parameters:
        A, B: list matrices, #columns(A) == #rows(B)
    Returns:
        C: a list matrix with the dot product
    
    Instructions:
        see exercise sheet!
        *
        Hint: for the sum, generate a list and use sum on this list
        Hint: with list comprehensions, this is easier than with for-loops!
    '''
    # your code here!

def apply_lima(A, fun):
    ''' apply function on every entry of a matrix
        
    Usage:
        B = apply_lima(A, fun)
    Parameters:
        A: list matrix
        fun: function which takes floats as parameters
    Returns:
        B: a list matrix B = fun(A)
    
    Instructions:
        see exercise sheet!
        *
        Hint: with list comprehensions, this is easier than with for-loops!
    '''
    # your code here!

def sandbox_lima():
    print 'the function "len" gives the number of elements in a list'
    list_a = range(5)
    print 'list_a: ', list_a
    length = len(list_a)
    print 'len(list_a): ', length
    
    print '\nthe function "str" converts a number into a string:'
    a = 46
    a_string = str(a)
    print a,
    print type(a)
    print a_string
    print type(a_string)
    
    print '\nstrings can be concatenated by "+"'
    string1 = 'strings'
    string2 = 'can be concatenated' 
    string3 = 'by "+"'
    long_string = string1 + ' ' + string2 + ' elegantly ' + string3 + '!'
    print long_string
    
    
    print '\nlist comprehension of a list comprehension: '
    list_matrix = [ [(i,j)  for j in range(3) ] for i in range(5)]
    print list_matrix
    list_matrix = [ [ str(i)+str(j)  for j in range(3) ] for i in range(5)]
    print list_matrix
    
    print '\n indexing a list_matrix: '
    list_matrix[0][1] = 'first row, second column'
    list_matrix[2][0] = 'third row, first column'
    print list_matrix
    
    


def test_mod_lima():
    ''' call this function to test your routines!
    '''
    assert( zeros_lima((2,3)) == [[0, 0, 0], [0, 0, 0]] )
    A = [[1, 0], [0, 1]]
    B = [[1, 2, 3], [4, 5, 6]]
    C = [[3, 2, 1], [6, 5, 4]]
    D = [[0, math.pi/2, 0],[0, 3*math.pi/2, 0]]  
    assert( emul_lima(B, C) == [[3, 4, 3], [24, 25, 24]] )
    assert(  matmul_lima(A,B) == [[1, 2, 3], [4, 5, 6]]  )
    assert( apply_lima(D,math.sin) ==  [[0.0, 1.0, 0.0], [0.0, -1.0, 0.0]] )
    assert( apply_lima(D,round) ==  [[0.0, 2.0, 0.0], [0.0, 5.0, 0.0]] )
    print 'Tests passed!'







'''Exercises II -- Task 4: numpy vs lima'''
import numpy as np
import pylab as pl
import time

def array_mult_for(A,B):
    ''' dot product of arrays A and B
        
    Usage:
        C = array_mult_for( A, B )
    Parameters:
        A, B: arrays, #columns(A) == #rows(B)
    Returns:
        C: an array with the dot product
    
    Instructions:
        - see exercise sheet!
        - This will replicate the funcitonality of numpy.dot()
        *
        Hint: for-loops are okay here!
    '''
    # your code here!
        
def timedcall(fn, *args):
    '''Call function with args; return the time in seconds and result.
        example: 
        You want to time the function call "C = foo(A,B)". 
        --> "T, C = timecall(foo, A, B)"
    '''
    # t0 = time.clock()
    t0 = time.time()
    result = fn(*args)
    # t1 = time.clock()
    t1 = time.time()
    return t1-t0, result

def matmul_performances(dims):
    ''' calculate time demand of different matrix multiplications
        
    Usage:
        T = matmul_performances(dims)
    Parameters:
        dims: dimensionalities to analyze, list of integer values
    Returns:
        T: an array of Time demands ( 3 x len(dims) )
    
    Instructions:
        takes as input a list of d dimensionalities and returns an 3xd array, where each 
        row contains a time demand:
        row 0: matmul_lima()
        row 1: array_mult_for()
        row 2: numpy.dot()
        *
        Hint: you might find "for i, d in enumerate(dims):" useful
        Hint: to generate a random numpy array, use numpy.random.rand()
    '''
    # your code here
    
def time_demands():
    ''' plots time demands!
        
    Usage:
        time_demands()
    Parameters:
        None
    Returns:
        None
    
    Instructions:
        see exercise sheet        
    '''
    # your code here
    
def sandbox_numpy():
    print 'generate a numpy array A of zeros: '
    A = np.zeros([2,3]) 
    print A

    print '\ngenerate a numpy array A of ones: '
    A = np.ones([2,3]) 
    print A

    print '\ngenerate a numpy array B of random entries: '
    B = np.random.rand(2,3) 
    print B

    print '\nmultiply an array by a factor: '
    A = 2*A
    print A

    print '\ncalculate an elementwise product of A and B: '
    C = A*B
    print C

    print '\nget the transpose of a matrix: '
    B_trans = B.T
    print B_trans

    print '\ncalculate the numpy dot product between A and the transpose of B: '
    C = np.dot(A,B_trans)
    print C

    print '\ngenerate a numpy array of random entries: '
    A = np.random.rand(4,3) 
    print A
    
    print '\n FOR-loops using enumerate can be quite useful: '
    colors = ['red','green','yellow','blue']    
    for ind, color in enumerate(colors):
        print 'index ' + str(ind) + ': ' + color
        
    print '\nThe file limaalg.py also contains a function "timed_call.'
    print 'We could, for example, time how long an elementwise product of two list matrices takes:'
    A = rand_lima([250,500])
    B = rand_lima([250,500])
    T, C  = timedcall(emul_lima, A, B)
    print T
    
    print '\n We can plot multiple curves with one plot command: '
    print 'generate some data: '
    A = np.arange(0.2, 2, 0.2)
    print A
    B = np.zeros([2,len(A)])
    B[0,:] = A**2
    B[1,:] = A**3
    print B
    
    print '\nplotting the data. note that B has to have the data in the columns'
    print '(this makes the transpose necessary)'
    pl.figure()
    pl.plot(A,B.T)
    pl.show()
    
    print '\nmaking a loglog-plot of the data: '
    pl.figure()
    pl.loglog(A.T,B.T)
    pl.show()
    
def test_mod_numpy():
    # test array_mult_for
    A = np.ones([3,4])
    B = np.ones([4,2])
    assert( np.all(  array_mult_for(A,B) == np.dot(A,B) ))
    dims = [3 , 50]
    T = matmul_performances( dims )
    assert(     np.all( T.shape == (3,len(dims)) )     )
    assert(     np.all( np.sort(T) == T )     )
    print 'Tests passed'
    
