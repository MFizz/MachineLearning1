'''Day 1 -- Exercises 1 -- Task 1

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show sine_waves.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import sine_waves as waves"
    to make the functions available
3.  If you make changes, type 
    In [xxx]: waves = reload(waves)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: waves.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    >>> waves.test_mod()
    
    Questions? Do not hesitate to ask!
'''

import math
import pylab as pl

frequencies = {'C_4': (261.63,'prime','consonant'),
               'G_4': (392.00,'perfect fifth','consonant'),
               'C_5': (523.25,'octave','consonant'),
                'B_4': (493.88,'major seventh','dissonant')
                }
                
def sine_comprehensions(f, n, xmin, xmax):
    ''' calculate a sine wave using list comprehensions
        
    Usage:
        x, y = sine_comprehensions(f, n, xmin, xmax)
    Parameters:
        f: frequency of the sine wave (float)
        n: number of observations (int)
        xmin: smallest x-value (float, default: 0)
        xmax: largest x-value (float, default: 1)
    Returns:
        x: grid between xmin and xmax with n points (list of floats)
        y: sine(x) (list of floats)
    
    Instructions:
    use list comprehensions to generate the lists X and Y such that
        - list X contains n values between xmin and xmax
        - list Y contains the sine of ( 2 * pi * f * X)
        return X and Y    
    '''
    # your code here
    return X, Y
    
def sine_for(f, n, xmin, xmax):
    ''' calculate a sine wave using "for-loops"
        
    Usage:
        x, y = sine_comprehensions(f, n, xmin, xmax)
    Parameters:
        f: frequency of the sine wave (float)
        n: number of observations (int)
        xmin: smallest x-value (float, default: 0)
        xmax: largest x-value (float, default: 1)
    Returns:
        x: grid between xmin and xmax with n points (list of floats)
        y: sine(x) (list of floats)
    
    Instructions:
    use a for loop to generate the lists X and Y such that
        - list X contains n values between xmin and xmax
        - list Y contains the sine of ( 2 * pi * f * X)
        return X and Y
        *
    '''
    X = []
    Y = []
    # your code here
    return X, Y
    
def sine_music()
    ''' plots some sine curves...
    '''
    # your code here
    return     

def sine_array(f, n, xmin, xmax):
    ''' a simple array version of the routines we wrote in Exercise 1 Task 1

   Usage:
        x, y = sine_array(f, n, xmin, xmax)
    Parameters:
        f: frequency of the sine wave (float)
        n: number of observations (int)
        xmin: smallest x-value (float, default: 0)
        xmax: largest x-value (float, default: 1)
    Returns:
        X: grid between xmin and xmax with n points (array)
        Y: sine(x) (array) 
    '''
    # your code here
    return X, Y
    

def sandbox():
    print 'sometimes it is useful to convert an integer into a float:'
    i , j = 1, 2
    print 'we have defined i and j:', i, j
    print 'if we divide i by j, we obtain: ', i/j
    print 'maybe conversion into float helps: ', float(i)/j
    
    print '\ngenerating a list of INTEGERS with range:'
    list_a = range(6)
    print list_a
    
    print '\nperforming a list comprehension:'
    print 'for all elements x in the list list_a, calculate the exponential exp(x)'
    exponentials = [math.exp(x) for x in list_a]
    print exponentials

    print '\nadding elements to a list'
    exponentials.append( math.exp(10) )
    print exponentials

    print '\nassigning list.append() to a variable assigns None!'
    exponentials2 = exponentials.append( math.exp(20) )
    print exponentials2
    
    print '\naccess the elements of a dictionary'
    note = frequencies['C_4']
    print 'the item belonging the note C_4: ', note
    
    print '\nsplitting up a tuple:'
    freq, interval, cd = note
    print 'freq: ',freq
    print 'interval: ',interval
    print 'cd: ',cd
    
    print '\n%timeit is a magic function and cannot be demonstrated in a function:'
    print 'In [xx] %timeit exp(100)'
    
    print '\nplotting something simple: '
    X = [0.1*x-5 for x in range(100)]
    Y = [x**2 for x in X]
    print 'call "pl.show(X,Y)" for two lists X and Y'
    pl.plot(X,Y)
    print 'call "pl.show()" to make the plot visible'
    pl.show()
    print 'with "pl.clf()" you could delete everything from the figure'
    # pl.clf()
    
def test_mod():
    assert( sine_comprehensions(1,2, 0, 0.25) == ([0.0, 0.25], [0.0, 1.0])  )
    assert( sine_for(1,2, 0, 0.25) == ([0.0, 0.25], [0.0, 1.0])  )
    print 'tests passed!'
            
    
    