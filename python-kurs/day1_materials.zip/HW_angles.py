'''Homework I -- Task 3

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_angles.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import HW_angles as ang
    to make the functions available
3.  If you make changes, type 
    In [xxx]: ang = reload(ang)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: ang.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    In [xxx] ang.test_mod()
    
    Questions? Do not hesitate to ask!
'''



import math
import pylab as pl

        

import numpy as np


def angles(X, k):
    ''' write an informative function header!
    
        for details, see homework sheet
    '''
    d, n = X.shape
    '''calculating the angle matrix W'''
    # your code here!
    '''calculate the average angle'''
    # your code here!
    '''extract maximum angles'''
    # your code here!
    return A, mA, k_max_mA

def sandbox():
    print 'let x be a random matrix of size (3 x 4)'
    x = np.random.rand(3,4)
    print x

    print '\n has x the correct shape?'
    sh = x.shape
    print sh

    print '\n calculate the transpose and store it in a variable xt'
    xtrans = x.T
    print xtrans

    print '\n invert the order of the columns in a 2D-array'
    xinvc = x[:,::-1]
    print xinvc

    print '\n calculate a matrix of the scalar product of the columns in x'
    scal_cols = np.dot(x,xtrans)
    print scal_cols

    print '\n calculate a matrix of the scalar product of the rows in x'
    scal_rows = np.dot(xtrans,x)
    print scal_rows

    print '\n calculate the sum of the columns of an array:'
    sumx = np.sum(x,0)
    print sumx

    print '\n convert a 1-D array into a 2D-array:'
    print 'shape of sumx: ', sumx.shape
    sumx2D = sumx[:,np.newaxis]
    print 'shape of sumx2D :', sumx2D.shape

    print '\n obtaining the indices sorting the elements of an 1D-array'
    inds = np.argsort(sumx)
    print inds

    print '\n using these indices to sort the 1D-array'
    sumx_sorted = sumx[inds]
    print sumx_sorted
    
    print 'using these indices to sort the columns of the original 2D-array'
    print x[:,inds]
    
    
def test_mod():
    ''' test the angles function '''
    X = np.array( [[1, 0, -1], [0, 1, 0] ] ) 
    W, mA, k_max_mA = angles(X, 2)
    pi = np.pi
    assert( np.all( W == np.array([ [0,pi/2,pi ],[pi/2,0,pi/2],[pi,pi/2,0]  ]) ) )
    assert( np.all( mA - np.array( [3./4*pi, 1./2*pi, 3./4*pi] ) <= 1e-8 ) )
    assert(    np.all( k_max_mA == np.array([ [ 1., -1.],[0., 0.]])  )
                  or np.all( k_max_mA == np.array([ [ -1., 1.],[0., 0.]]) )       )
    print 'Tests passed!'
    
