""" this is a useless module which contains an useless function
"""
import math
import random

def a_useless_function(n):
    ''' sometimes calculates the sine of n
    
    Usage:
        x = a_useless_function(n):
    Parameters:
        n: an integer or float    
    Returns:
        x: the sine of n with 50% probability, else n
        
    This does not make any sense, but: hey, it is a function!
    '''
    if random.random() >= 0.5:
        return n
    else:
        return math.sin(n)
