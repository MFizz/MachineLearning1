'''Homework I -- Task 3

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_heron.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import HW_heron as heron
    to make the functions available
3.  If you make changes, type 
    In [xxx]: reload(heron)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: heron.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    In [xxx] heron.test_mod()
    
    Questions? Do not hesitate to ask!
'''



import math
import pylab as pl

# import pdb
        
import numpy as np


def heron_comparison(r):
    ''' generates a plot of the error after one to four heron steps!

   Usage:
        heron_comparison(r)
    Parameters:
        r: errors are given for square roots of inteters 1, 2, ..., r
    Returns:
        x: grid between xmin and xmax with n points (array)
        y: sine(x) (array) 
        for details, see homework sheet
    '''
    x = range(1,r+1)
    conv = np.zeros([1,r])
    y = np.zeros([4,r])
    for number in x:
        conv[0,number] = heron(number)
        y[0,number] = heron(number,1)
        y[1,number] = heron(number,2)
        y[2,number] = heron(number,3)
        y[3,number] = heron(number,4)
    # plot the results:
    error = np.abs(conv-y)
    xlab = 'x'
    ylab = 'square root of x'
    pl.figure(figsize=(16,10))    
    pl.xlabel(xlab,fontsize=18)
    pl.ylabel(ylab,fontsize=18)
    lineObjects = pl.semilogy(x,error,'+', markersize=20)
    pl.grid()
    pl.legend(lineObjects, ('1 step', '2 steps','3 steps','4 steps'),loc=2,numpoints=1)
    pl.show()    
    print 'Bug #1'
    print 'Description:'
    print 'INSERT BUG DESCRIPTION'
    print 'Fix:'
    print 'INSERT FIX DESCRIPTION'
    print '*'
    print 'Bug #2'
    print 'Description:'
    print 'INSERT BUG DESCRIPTION'
    print 'Fix:'
    print 'INSERT FIX DESCRIPTION'
    print '*'
    print 'Bug #3'
    print 'Description:'
    print 'INSERT BUG DESCRIPTION'
    print 'Fix:'
    print 'INSERT FIX DESCRIPTION'
    print '*'


def heron(n,nsteps= float('Inf'),tol=10e-10):
    ''' the heron procedure for calculating square roots

   Usage:
        heron(n, nsteps, tol)
    Parameters:
        n: functions returns sqrt(n)
        nsteps: number of iteration steps
        tol = accuracy to which the square root is calculated
    Returns:
        root: square root of n
    '''
    # pdb.set_trace()
    root = (n+1)/2
    step=1
    converged = False
    while step <= nsteps and not converged:
        root = (root + n/root)/2
        if np.abs(root**2 - n) < tol:
            converged = True
        step = step + 1
    return root

def sandbox():
    print 'remember the guided debugging from exercise sheet 2!'
    
    
def test_mod():
    ''' tests the heron functions '''
    print 'test heron method:'
    print 'call heron(5):'
    print 'heron(5) = ' + str(heron(5))
    print ' '
    print 'test heron comparison'
    print 'call heron_comparison(20):'
    heron_comparison(20)
        
    print 'Tests passed!'
    
