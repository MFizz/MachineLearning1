""" a very important script which outputs a warm welcome
"""
print 'Welcome to "Python Programming for Machine Learning"!'