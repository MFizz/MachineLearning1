'''Day I -- Homework I -- Task 1

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_sine_waves.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import HW_sine_waves as beauty
    to make the functions available
3.  If you make changes, type 
    In [xxx]: beauty = reload(beauty)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: beauty.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    
    
    Questions? Do not hesitate to ask!
'''


import math
import pylab as pl
        

import numpy as np

frequencies = {'C_4': (261.63,'prime','consonant'),
               'G_4': (392.00,'perfect fifth','consonant'),
               'C_5': (523.25,'octave','consonant'),
                'B_4': (493.88,'major seventh','dissonant')
                }

def sine_array(f, n, xmin, xmax):
    ''' a simple array version of the routines we wrote in Exercise 1 Task 1

   Usage:
        x, y = sine_array(f, n, xmin, xmax)
    Parameters:
        f: frequency of the sine wave (float)
        n: number of observations (int)
        xmin: smallest x-value (float, default: 0)
        xmax: largest x-value (float, default: 1)
    Returns:
        x: grid between xmin and xmax with n points (array)
        y: sine(x) (array) 
    '''
    scaling = float(xmax-xmin)/(n-1)
    X = scaling*np.arange(n)
    omega = 2*f*math.pi
    Y = np.sin(omega*X)
    return X, Y


def beautiful_sines():
    ''' This function generates beautiful plots of sine waves!
    
        !!! your header here !!!
        For details, see homework sheet!
        *
        Hint: matplotlib/pylab is imported as pl (see above). To call e.g. "plot" from this
              function, you have to use "pl.plot"
        Hint: use str() to convert an integer or float into a string
    '''
    #your code here

def sandbox():
    print 'let us plot two curves next to each other: '
    print 'for details, see limaalg!: '
    A = np.arange(0.1, 10, 0.1)
    B1 = A**2
    B2 = A**3
    
    pl.figure(figsize=(16,10))
    for i in [1,2]:
        print '\ngenerating subplots, activating the i-th'
        pl.subplot(1,2,i)   
        if i == 1:
            print '\ndraw the first plot (loglog): '
            pl.plot(A,B1,label='x**2')
            pl.plot(A,B2,label='x**3')
            pl.title('standard plot')
            pl.ylabel('y',fontsize=18)
        elif i == 2:
            print '\ndraw the second plot (loglog): '
            pl.loglog(A,B1,label='x**2')
            pl.loglog(A,B2,label='x**3')
            pl.title('loglog plot')
            pl.xticks([0.1, 1./3, 1, 10./3, 10],['0.1', '0.33333', '1', '3.3333', '10'])
        print 'add a grid'
        pl.grid()
        print 'labels'
        pl.xlabel('x',fontsize=18)
        pl.legend(loc='upper left')
    pl.savefig('standard_vs_loglog.pdf')

    print 'displaying: '    
    pl.show()
    
    