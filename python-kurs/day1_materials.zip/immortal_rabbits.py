'''Day 1 -- Exercises 1 -- Task 2

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show immortal_rabbits.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import immortal_rabbits as ir"
    to make the functions available
3.  If you make changes, type 
    In [xxx]: ir = reload(ir)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: ir.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    >>> ir.test_mod()
    
    Questions? Do not hesitate to ask!
'''

def fibo(n):
    ''' implementation of the recursive calculation of Fibonacci numbers
        
    Usage:
        f = fibo(n)
    Parameters:
        n: the Fibonacci number to calculate (int)
    Returns:
        f: the n-th Fibonacci number
    
    Instructions:
        see exercise sheet!
    '''
    # your code here!



memo = {}
def fibo_memo(n):
    ''' Fibonacci numbers, using a dictionary to avoid repetitive calculations.
        
    Usage:
        f = fibo_memo(n)
    Parameters:
        n: the Fibonacci number to calculate (int)
    Returns:
        f: the n-th Fibonacci number
    
    Instructions:
        see exercise sheet!
        *
        Hint: the dictionary memo has already been specified for you
    '''
    # your code here!
    
    
def sandbox():
    print 'remember how if statements work:'
    A, B, C = 1, 2, 3
    if A == B:
        print "A is equal to B"
    elif A == C:
        print "A is equal to C"
    else:
        print "A is neither equal to B nor C"
        
    print '\ndictionaries: define a dictionary consisting of key-value-pairs'
    test_dict = {'python': 'great!', 1: 'a one', 'five': 5}
    print test_dict
    
    print '\naccess an elenement:'
    pyth = test_dict['python']
    print pyth
    
    print '\nadd an elenement with key "matlab" and value "please, no!":'
    test_dict['matlab'] = 'please, no!'
    print test_dict
    
    print '\nthe "dict"-class has many functions:'
    print 'an example: keys'
    print test_dict.keys()    
    print 'another example: values'
    print test_dict.keys()
    
    print '\nTo find out more about these functions in Ipython, type'
    print 'In [xxx]: dict.<TAB>' 

    print '\nFind THE function in Ipython by getting information on all functions in "dict"'
    print 'start with: "dict.clear", type:'
    print 'In [xxx]: dict.clear?' 
    
    
    
            
    
def test_mod():
    assert(     fibo(0) == 0     )
    assert(     fibo(1) == 1     )
    assert(     fibo(20) == 6765     )
    assert(     fibo_memo(0) == 0     )
    assert(     fibo_memo(1) == 1     )
    assert(     fibo_memo(40) == 102334155     )
    print 'tests passed!'        