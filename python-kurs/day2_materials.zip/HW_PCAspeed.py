'''Day 2 -- Exercises 1 -- Task 2

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show PCAspeed.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import PCAspeed as speed"
    to make the functions available
3.  If you make changes, type 
    In [xxx]: speed = reload(speed)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: speed.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    [xxx]: speed.test_mod()
    
    Questions? Do not hesitate to ask!
'''
import numpy as np
import scipy.linalg as la
import pylab as pl
import time





def speed(dims):
    ''' calculate time demand of eigenvalue decompositions via eig
        
    Usage:
        T = speed(dims)
    Parameters:
        dims: dimensionalities to analyze, list of integer values
    Returns:
        T: a 1D-array of time demands of shape (   len(dims), )
    
    Instructions:
        *
        Hint: you might find "for i, d in enumerate(dims):" useful
        Hint: to generate a random numpy array, use numpy.random.rand()
        Hint: use timedcall (see below!)
    '''
    # your code here    

def speed_plots():
    ''' visualizes time demands of eigenvalue decomposition and saves a figure
        
    Usage:
        speed_plots()
    Parameters:
        -
    Returns:
        -
    
    Instructions:
        see exercise sheet
    '''
    # your code here
        
def new_camera():
    # your code here    

def timedcall(fn, *args):
    '''Call function with args; return the time in seconds and result.
        example: 
        You want to time the function call "C = foo(A,B)". 
        --> "T, C = timecall(foo, A, B)"
    '''
    # t0 = time.clock()
    t0 = time.time()
    result = fn(*args)
    # t1 = time.clock()
    t1 = time.time()
    return t1-t0, result

def sandbox():
    print 'No new commands needed here!'
    print '- see eigenfaces.py for eigenvalue decomposition'
    print '- see limaalg.py for timedcall'
    print '- see HW_sine_waves.py for visualization'

def test_mod():
    ''' perform some test on the routine '''
    dims = [3 , 100, 200]
    T = speed( dims )
    assert(     np.all( T.shape == (len(dims),) )     )
    assert(     np.all( np.sort(T) == T )     )
    print 'Tests passed!'
    
