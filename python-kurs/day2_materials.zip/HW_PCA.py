'''Homework II -- Task 3

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_PCA.py

1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab

2.  From Ipython, use 
    In [xxx]: import HW_PCA as pca
    to make the functions available

3.  If you make changes, type 
    In [xxx]: pca = reload(pca)
    to makes the new versions available in Ipython

4. The file contains a function sandbox(). Type
    In [xxx]: pca.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    

5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    In [xxx] pca.test_mod()
    
    Questions? Do not hesitate to ask!
'''
import numpy as np
import scipy.linalg as la
import scipy.io
import pylab as pl

import kmeans_utils as kmu
import HW_nmf_utils as nmfu
import bimp

def pca(X, k):
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
    '''
    # your code here
    
def usps5():
    ''' your Header here!
    
    Instructions:
        see exercise sheet!
        *
        Hint: use pca!
        Hint: 
    '''
    # your code here

def sandbox():
    print 'unfortunately, you have to write your own sandbox...'
     
        
def test_mod():
    print 'unfortunately, you have to write your own tests...'