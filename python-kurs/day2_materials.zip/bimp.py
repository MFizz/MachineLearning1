''' Day 2: basic image processing

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show bimp.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import bimp"
    to make the functions available
3.  If you make changes, type 
    In [xxx]: bimp = reload(bimp)
    to makes the new versions available in Ipython
4. The file contains a sandbox-function. Type
    In [xxx]: bimp.sandbox()
    to run some code snippets which might be useful for the exercises.
    Feel free to play around with these snippets!
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    In [xxx] bimp.test_mod()
    
    Questions? Do not hesitate to ask!
'''

import math
import numpy as np
import pylab as pl

def im2vec(images):
    ''' converts a 3D array into a 2D array by flattening images
        
    Usage:
        images, fact = im2vec(images)
    Parameters:
        images: an 3D array (X x Y x N) containing N  (X x Y)-images
    Returns:
        images: a 2D array (X*Y x N) containing N flattened images (X*Y)
        fact: a tuple (X, Y) containing X and Y
    Instructions:
        see exercise sheet!
        *
        Hint: use reshape!
    '''
    # your code here!
    
def vec2im(images, fact=False):
    ''' converts a 2D array into a 3D array by de-flattening images
        
    Usage:
        images = im2vec(images)
    Parameters:
        images: a 2D array (X*Y x N) containing N flattened images (X*Y)
        fact: a tuple (x,y) of the correct factorization of X*Y (optional)
    Returns:
        images: an 3D array (X x Y x N) containing N images (X x Y)
    
    Instructions:
        - If fact is given, use this factorization!
          Else:
          X*Y is factored such that X takes the largest possible value such that 
          (i) X is smaller or equal to the square root of X*Y
          (ii) X divides X*Y
        - see exercise sheet!
        *
        Hint: use reshape!
        Hint: the automatic factorization does not work for the xkcd images
    '''
    # your code here!
        
def notext():
    ''' displays the xkcd image with a light gray tree without a text
        
    Usage:
        notext()
    Parameters:
        None
    Returns:
        None
    
    Instructions:
        - see exercise sheet!
        *
        Hint: follow the steps on the exercise sheet!
    '''
    # your code here
    
    
    
def sandbox():
    'Let us see how this saving and loading works. Let us first generate some data'
    a = np.arange(6)
    print 'a = ', a
    b = 10*a[:,np.newaxis]
    print 'b = ', b
    print 'calculate a matrix c by broadcasting'
    c = 2*a + b
    print 'c = ', c
        
    print '\nsave the matrix to a file "broadcasted.npz":'
    np.savez('broadcasted',c)
    
    print '\nload the file and see what is inside'
    a = np.load('broadcasted.npz')
    print a.files
    
    print '\nstore the contained variable in a variable named "L":'
    L = a['arr_0']
    print 'L = ',L
    
    print '\nusing "pylab.imshow" to visualize the array:'
    pl.figure()
    pl.imshow(L)
    pl.show()
    
    print '\nusing "pylab.imshow" with a different colormap:'
    pl.figure()
    pl.imshow(L,cmap='gray')
    pl.show()
    
    print 'remember how to reshape an array and how to use the shape property'
    mat3D = np.random.rand(2,3,4)
    sh = mat3D.shape
    print 'shape of mat3D = ', sh    
    mat2D = mat3D.reshape(2*3,4)
    sh = mat2D.shape
    print 'shape of mat2D = ', sh
    print 'using "automatic missing dimension" estimation:'
    mat4D = mat2D.reshape(2,3,2,-1)
    sh = mat4D.shape
    print 'shape of mat2D = ', sh
    
    
    
    
    

    
def test_mod():
    a = np.load('xkcd1.npz')
    im = a['W']
    vec, fact = im2vec( im )
    assert(     (   vec2im(vec, fact) == im   ).all()     )
    print 'tests passed!'