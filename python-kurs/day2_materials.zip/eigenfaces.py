""" Day 2 -- Exercicse: Eigenfaces

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show eigenfaces.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import eigenfaces as ef
    to make the functions available
3.  If you make changes, type 
    In [xxx]: ef = reload(ef)
    to makes the new versions available in Ipython
4. The file contains a sandbox-function. Type
    In [xxx]: ef.sandbox()
    to run some code snippets which might be useful for the exercises.
    Feel free to play around with these snippets!
    
    Questions? Do not hesitate to ask!
'''

"""
import numpy as np
import scipy.linalg as la
import pylab as pl

import nmf_utils as nmfu
import bimp

import time


def eigenfaces_script():
    ''' does a pca analysis
        
    Usage:
        eigenfaces_script( )
    Parameters:
        -
    Returns:
        -
    
    Instructions:
        follow the steps on the exercise sheet!
        *
        Hint: broadcasting is your friend!
    '''
    # your code here:

def timedcall(fn, *args):
    '''Call function with args; return the time in seconds and result.
        example: 
        You want to time the function call "C = foo(A,B)". 
        --> "T, C = timecall(foo, A, B)"
    '''
    t0 = time.clock()
    result = fn(*args)
    t1 = time.clock()
    return t1-t0, result


def sandbox():
    print 'start by generating a random vector'
    X = np.random.rand(2,3)
    print 'X = ', X
    print 'X.shape = ', X.shape
    
    print '\nthe sum and mean functions are useful!'
    sX = np.sum(X)
    mX = np.mean(X)
    print 'sX = ', sX
    print 'mX = ', mX

    print '\nsum over rows and sum over columns:'
    srowX = np.sum(X,0)
    print 'srowX = ', srowX
    print 'srowX.shape = ', srowX.shape
    scolX = np.sum(X,1)
    print 'scolX = ', scolX
    print 'scolX.shape = ', scolX.shape
    
    print '\nmaking the sum of rows a 2D-row (numpy 2.3.0):'
    srowX2D = srowX[np.newaxis,:]
    print 'srowX2D = ', srowX2D
    print 'srowX2D.shape = ', srowX2D.shape

    print '\nmaking the sum of columns a 2D-columns:'
    scolX2D = scolX[:,np.newaxis]
    print 'scolX2D = ', scolX2D
    print 'scolX2D.shape = ', scolX2D.shape

    print '\ndirect versions:'
    srowX2D = np.sum(X,0)[np.newaxis,:]
    print 'srowX2D = ', srowX2D
    print 'srowX2D.shape = ', srowX2D.shape
    scolX2D = scolX[:,np.newaxis]
    print 'scolX2D = ', scolX2D[:,np.newaxis]
    print 'scolX2D.shape = ', scolX2D.shape
    
    print 'eigenvalue decomposition:'
    print '(a) generate a symmetrix matrix:'
    S = np.dot(X, X.T)
    print '\n(b) callling eig'
    l, v = la.eig(S)
    print 'l = ', l
    print 'v = ', v
    print '\n(c) callling eigh'
    lh, vh = la.eigh(S)
    print 'lh = ', lh
    print 'vh = ', vh
    print 'Do you see a difference? What could be an additional difference?'
    
    print '\n projecting a vector on a normalized vector:'
    some_vector = np.random.rand(3,1)
    print 'some_vector =  ', some_vector
    basis_vector = np.array([[1],[0],[0]])
    print 'basis_vector =  ', basis_vector
    print 'projection'
    proj = np.dot(basis_vector.T,some_vector)
    proj_vector = basis_vector * proj
    print 'proj_vector =  ', proj_vector
    
    print '\n young gauss used python!'
    print 'eacher: calculate the sum of all numbers between 1 and 100!'
    cumulated = np.cumsum(range(101))
    print "gauss: easy! That's ", cumulated[-1] 
    print "cumulated sum:"
    print cumulated
    
    print "\n learn about numpy's covariance matrix estimation! Type in Ipython"
    print 'np.cov?'
    
    print "appending vectors. Might be useful,"
    print 'assume we want to append a column vector to a matrix:'
    A = np.arange(6).reshape(2,3).T
    a = np.arange(3).reshape(3,1)+6 
    print 'A = '
    print A
    print 'a = '
    print a
    Aa = np.append(A,a,1)
    print 'Aa = '
    print Aa
    
    
def test_mod():
    print 'nothing to test here...'
    

