'''Homework I -- Task 2

General Instructions and Hints:
0.  Open a shell and change to the directory where the course material lies:
    xxx$ cd YOUR_FOLDER
    xxx$ ls
    The ls command should show HW_nmf_utils.py
1.  Start Ipython with from the shell: type
    xxx$ ipython --pylab
2.  From Ipython, use 
    In [xxx]: import HW_nmf_utils as nmfu
    to make the functions available
3.  If you make changes, type 
    In [xxx]: nmfu = reload(nmfu)
    to makes the new versions available in Ipython
4. The file contains a function sandbox(). Type
    In [xxx]: nmfu.sandbox()
    to run some code snippets which might be useful for the exercises
    Feel free to play around with these snippets!    
5.  The file contains a module which does some tests! 
    When you have finished a function, type 
    In [xxx] nmfu.test_mod()
    
    Questions? Do not hesitate to ask!
'''


import numpy as np
import scipy
import pylab as pl
import random as rm

import bimp
        
    
def load_data(dataset='swimmer'):
    ''' a file loading routine for three data sets. See the homework sheet for details
        
        Instructions:
        return an array of floats! Use result = result.astype(float)
        * 
        Hint: there is a subtlety involved when loading 'orl32'. visualize one of these 
              images, then improve the code! 
        Hint: to convert an array  A into an array of floats, use "A = A.astype(float)"
    '''    
    # your code here

def visualize_data(data, subs=(3,4) , rand=False):
    ''' visualize a set of images.
        For Details, see homework sheet.
        *
        Hint: first generate a large empty array of correct shape!
    '''
    # your code here
        

def sandbox():
    print 'load data'
    a = np.load('xkcd1.npz')
    print 'contents of the file: ', a.files
    im = a['W']
    print 'draw a figure'
    pl.figure()
    pl.imshow( im[:,:,1]+  im[:,:,2] + im[:,:,3], cmap='gray')
    print 'remove tick marks'
    pl.xticks([],[])
    pl.yticks([],[])
    
def test_mod():
    im, lab = load_data('swimmer')
    assert( im.shape == (32, 32, 256) )
    im, lab = load_data('orl32')
    assert( im.shape == (32, 32, 400) )
    im, lab = load_data('xkcd')
    assert( im.shape == (316, 515, 6) )
    im, lab = load_data('usps')
    assert( im.shape == (16,16, 2007) )
    assert( lab.shape == (10, 2007) )
    print "Tests passed!"
    

